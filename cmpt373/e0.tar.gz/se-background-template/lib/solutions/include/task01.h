// ID 9c8e9a75094246cdd2d9884e896a9b8d
#pragma once

int task01(int value);
