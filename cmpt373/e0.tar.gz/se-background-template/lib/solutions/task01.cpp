// ID 9c8e9a75094246cdd2d9884e896a9b8d

#include "task01.h"

int task01(int value) {
    value += 1;
    return value;
}