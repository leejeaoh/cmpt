#include "sos.h"
#include <print>

int main() {
  std::println("What a lovely day for a {}", getSecret());
  return 0;
}
