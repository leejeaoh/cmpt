
#include "sos.h"

uint64_t
getSecret() {
  return 8589869056;
}

