#pragma once

#include <cstdint>

uint64_t getSecret();

