
# Example Dependency

This is an example remote dependency meant to be used as part of an exercise
demonstrating the basics of CMake and remote depenency management using
CPM.

