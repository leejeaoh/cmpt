#include <algorithm>
#include <vector>

void sortIntegers(std::vector<int> &numbers) {
  std::ranges::sort(numbers);
}